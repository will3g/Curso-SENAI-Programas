//DIRETIVAS include fuses use
#include <16f877a.h>
#fuses XT, NOPROTECT, NOWDT, NOLVP
//intrc_io se eu fosse usar clock interno as ta osso aqui
#use delay(clock=4000000)
//p serial
#use rs232(baud=9600, parity=n, bits=8, xmit=pin_c6, rcv=pin_c7)
//p lcd
#use fast_io(b)
#define use_portb_lcd TRUE //padrao usa port d
#include <MOD_LCD.C>

#include <string.h>
#include <stdio.h>
#include <input.c>

//DEFINIÇÕES

//VARIAVEIS GLOBAIS

unsigned int8 image[8]={0,0,0,0,0,0,0,0};
boolean escritaflag=0,cgramflag=0, animacaoflag=0, testeflag = 0;
char ch,ch1,cha;
int cont=-2;
unsigned int8 xy=-3,xi=5,yi=1;
void animacao();
void teste();
void escrita();

int hb0[]={0b01110,0b11011,0b10001,0b10001,0b10001,0b10001,0b10001,0b11111,};
int hb1[]={0b01110,0b11011,0b10001,0b10001,0b10001,0b10001,0b11111,0b11111,};
int hb2[]={0b01110,0b11011,0b10001,0b10001,0b10001,0b11111,0b11111,0b11111,};
int hb3[]={0b01110,0b11011,0b10001,0b10001,0b11111,0b11111,0b11111,0b11111,};
int hb4[]={0b01110,0b11011,0b10001,0b11111,0b11111,0b11111,0b11111,0b11111,};
int hb5[]={0b01110,0b11011,0b11111,0b11111,0b11111,0b11111,0b11111,0b11111,};
int hb6[]={0b01110,0b11111,0b11111,0b11111,0b11111,0b11111,0b11111,0b11111,};


//FUNÇÕES

void lcd_set_cgram_char(unsigned int8 which, unsigned int8 *ptr)
{
   unsigned int i;

   which <<= 3;
   which &= 0x38;

   lcd_envia_byte(0, 0x40 | which);  //set cgram address

   for(i=0; i<8; i++)
   {
     lcd_envia_byte(1, *ptr++);
   }
  
   #if defined(LCD_EXTENDED_NEWLINE)
    lcd_pos_xy(g_LcdX+1, g_LcdY+1);  //set ddram address
   #endif
}

void cgram()
{
//VALOR X - COLUNA          VALOR Y - LINHA
if(xy==12 && ch!='y'){xi=10+(ch-48);xy=11;}
if(xy==9){xi=ch-48; xy=12;}
if(xy==10) {yi=ch-48; xy=11;}
if(ch=='x'){xy=9;}
if(ch=='y'){xy=10;}

//DESENHO
if(ch=='h')
{
lcd_set_cgram_char(1 ,image);
lcd_pos_xy(xi,yi);
lcd_escreve(1);xy==0;
}

//VALORES DA CGRAM
if(ch!="" && (cha=='a'||cha=='b'||cha=='c'||cha=='d'||cha=='e'||cha=='f'||cha=='g') && image[xy]==0)
{image[xy]=ch-48;}

if(ch!="" && (cha!='a'||cha!='b'||cha!='c'||cha!='d'||cha!='e'||cha!='f'||cha!='g'||cha!='h') && image[xy]!=0 && (cha=='1'||cha=='2'||cha=='3')&&(xy>=0 && xy<=6)&&(ch=='0'||ch=='1'||ch=='2'||ch=='3'||ch=='4'||ch=='5'||ch=='6'||ch=='7'||ch=='8'||ch=='9'))
{image[xy]= (image[xy]*10)+(ch-48);}

cha=ch;

if(ch=='a'){xy=0;image[1]=0, image[2]=0, image[3]=0, image[4]=0, image[5]=0, image[6]=0, image[7]=0, image[0]=0;}
if(ch=='b'){xy=1;}
if(ch=='c'){xy=2;}
if(ch=='d'){xy=3;}
if(ch=='e'){xy=4;}
if(ch=='f'){xy=5;}
if(ch=='g'){xy=6;}
}


#int_rda
void serial_isr()
{
ch=getchar();
   
     //CGRAM
   if(cgramflag==1)
   { 
     ch1=ch;
     if(ch=='s'){lcd_escreve("\f");image[0]=0; image[1]=0; image[2]=0; image[3]=0; image[4]=0; image[5]=0; image[6]=0; image[7]=0;}
     else cgram();         
   }else{cgramflag=0;}
   if(ch == 'c') //se char1 bater
   { 
      ch1=ch; 
   }
   if(ch1 == 'c' && ch == 'g') // se char anterior for igual a w e atual for + chama função animação
   {  
      xy=0-2;ch1="";
      lcd_escreve("\f");
      escritaflag=0; animacaoflag=0; testeflag=0; cgramflag=1;
      cgramflag=1;      
   } 
   
     if(ch == '[') //se char1 baterx
   { 
      lcd_escreve("/f");
      escritaflag=0; animacaoflag=1; testeflag=0; cgramflag=0;
      ch1 = ch;      
   }
     if(ch1=='['&& ch==']'){
      ch=""; printf(lcd_escreve,"\f");
      escritaflag=0; animacaoflag=1; testeflag=0; cgramflag=0;}
     if (animacaoflag==1){lcd_envia_byte(0,0x80); animacao();} else {animacaoflag=0;}

    if(ch == 'e') //se char1 baterx
   { 
   ch1 = ch;
   }
     if(ch1=='e'&& ch=='s'){
      escritaflag=1; animacaoflag=0; testeflag=0; cgramflag=0;}
     if (escritaflag==1){lcd_envia_byte(0,0x80); cont++; escrita();} else {escritaflag=0;}
     
      if(ch == '{') //se char1 baterx
   { 
   ch1 = ch;
   }
     if(ch1=='{'&& ch=='}'){escritaflag=0; animacaoflag=0; testeflag=1; cgramflag=0; lcd_envia_byte(0,0x80); }
     if (testeflag==1){teste();} else {testeflag=0;}
    
}

void escrita()
{
    
      if (cont==32)
      {
      printf(lcd_escreve, "\f");
      cont=0;
      }      
      if (cont==16)
      {
      printf(lcd_escreve, "\n");
      }

printf(lcd_escreve, "%c",ch);
    
       if(ch == 'e') //se char1 bater
      { 
        ch1 = 'e';
      }
       if(ch1 == 'e' && ch == 's')
      {
      printf(lcd_escreve,"\f"); cont=0;
      }
      
}

void teste()
{
int cont;
char lcd[16];

for(cont=0;cont<16;cont++)
{
lcd[cont]=255;
printf(lcd_escreve,"%s\n%s",lcd,lcd);
}
}
void animacao()
{   
if(animacaoflag == 1){
    {   lcd_escreve('\f');
      lcd_set_cgram_char(0,hb0);
      lcd_pos_xy(1,1);
      printf(lcd_escreve,"%c", 0); 
       delay_ms(400);
      lcd_set_cgram_char(1,hb1);
      lcd_pos_xy(1,1);
      printf(lcd_escreve,"%c", 1); 
       delay_ms(400);
        {  lcd_pos_xy(5,1);
      printf(lcd_escreve,"Lucas o pequeno");

       lcd_pos_xy(5,2);
      printf(lcd_escreve,"Principe!");
      delay_ms(500);
}
      lcd_set_cgram_char(2,hb2);
      lcd_pos_xy(1,1);
      printf(lcd_escreve,"%c", 2); 
       delay_ms(400);
      lcd_set_cgram_char(3,hb3);
      lcd_pos_xy(1,1);
      printf(lcd_escreve,"%c", 3);
      delay_ms(400);
      {
       lcd_pos_xy(5,1);
      printf(lcd_escreve,"           ");

       lcd_pos_xy(5,2);
      printf(lcd_escreve,"           ");
      delay_ms(500);
}
       
      lcd_set_cgram_char(4,hb4);
      lcd_pos_xy(1,1);
      printf(lcd_escreve,"%c", 4); 
       delay_ms(400);
       {  lcd_pos_xy(5,1);
      printf(lcd_escreve,"Pequeno");

       lcd_pos_xy(5,2);
      printf(lcd_escreve,"Principe");
      delay_ms(500);
}
      lcd_set_cgram_char(5,hb5);
      lcd_pos_xy(1,1);
      printf(lcd_escreve,"%c", 5); 
       delay_ms(400);
      lcd_set_cgram_char(6,hb6);
      lcd_pos_xy(1,1);
      printf(lcd_escreve,"%c", 6); 
        delay_ms(400);
        {
       lcd_pos_xy(5,1);
      printf(lcd_escreve,"           ");

       lcd_pos_xy(5,2);
      printf(lcd_escreve,"           ");
      delay_ms(500);
}
 
      lcd_set_cgram_char(5,hb5);
      lcd_pos_xy(1,1);
      printf(lcd_escreve,"%c", 5); 
       delay_ms(400);
        {  lcd_pos_xy(5,1);
      printf(lcd_escreve,"Pequeno");

       lcd_pos_xy(5,2);
      printf(lcd_escreve,"Principe");
      delay_ms(500);
}
        lcd_set_cgram_char(4,hb4);
      lcd_pos_xy(1,1);
      printf(lcd_escreve,"%c", 4); 
       delay_ms(400);
         {
       lcd_pos_xy(5,1);
      printf(lcd_escreve,"           ");

       lcd_pos_xy(5,2);
      printf(lcd_escreve,"           ");
      delay_ms(500);
}
        lcd_set_cgram_char(3,hb3);
      lcd_pos_xy(1,1);
      printf(lcd_escreve,"%c", 3); 
       delay_ms(400);
        {  lcd_pos_xy(5,1);
      printf(lcd_escreve,"Pequeno");

       lcd_pos_xy(5,2);
      printf(lcd_escreve,"Principe");
      delay_ms(500);
}
        lcd_set_cgram_char(2,hb2);
      lcd_pos_xy(1,1);
      printf(lcd_escreve,"%c", 2); 
       delay_ms(400);
         {
       lcd_pos_xy(5,1);
      printf(lcd_escreve,"           ");

       lcd_pos_xy(5,2);
      printf(lcd_escreve,"           ");
      delay_ms(500);
}
        lcd_set_cgram_char(1,hb1);
      lcd_pos_xy(1,1);
      printf(lcd_escreve,"%c", 1); 
       delay_ms(400);
     
     lcd_escreve("\f");
     animacaoflag=0; }
}
   if(animacaoflag==0){ lcd_escreve("\f"); escritaflag = 1; }
   }

//PROGRA
void main()
{
enable_interrupts(GLOBAL);
enable_interrupts(int_rda);

lcd_ini();
delay_ms(200);
 
   while(1)
   {  
   
   }      
}

//Caracteres editados no endere�os de 00 a 07 da GGRAM
//lobosoft@oi.com.br
#include <16F877A.h>
#device ADC=10 //Canal anal�gico de 10 bits.
#use delay(clock=20000000)
#fuses HS, PUT, NOWDT, NOBROWNOUT, NOLVP

#include "flex_lcd.c"
//#include "cuscostdio.h"

//Caracter 0 >CGRAM padr�o 5x7< para biblioteca flex_lcd.c
const char Linha_0[] = {0x46,0x49,0x49,0x46,0x40,0x40,0x40,0x40};
void Ex_LCD_0(char Ex_x, char Ex_y)
     {
     char f;
     lcd_send_byte(0,0x40);
     for (f = 0; f<=7; f++) lcd_send_byte(1,Linha_0[f]);
     lcd_gotoxy(Ex_x, Ex_y); lcd_putc(0);
     }


//==========================================
void main()
{
lcd_init();
delay_ms(100);

   delay_ms(100);
   lcd_gotoxy(1, 1); lcd_putc("CELSIUS");
   lcd_gotoxy(1, 2); lcd_putc("29,5 C");
   Ex_LCD_0(5, 2);
   
while(true);
}

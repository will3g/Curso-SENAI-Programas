
/*
BIBLIOTECA PADR�O PARA CUSCOPIC
Desenvolvida para PICs fam�lias 16 ou 18 de 28 ou 40 pinos.
Autor: Daniel Corteletti
Desenvolvido em agosto de 2007
Revis�o em setembro 2007
Revis�o em novembro 2008
   --> Adi��o de timeout (mediante vari�vel global de configura��o) para fun��o cusco_readkbd()
   --> Vari�vel global cusco_readkbd_timeout c/ valor padr�o 0
   --> Adi��o de rotinas de grava��o e leitura da eeprom em 16 e 32 bits.

*/

#define RELE1 pin_e0
#define RELE2 pin_e1
#define BUZZER pin_e2
#define C0 pin_c0
#define C1 pin_c1
#define C2 pin_c2
#define C3 pin_c3
#define C4 pin_c4
#define C5 pin_c5
#define C6 pin_c6
#define C7 pin_c7
#define D0 pin_d0
#define D1 pin_d1
#define D2 pin_d2
#define D3 pin_d3
#define D4 pin_d4
#define D5 pin_d5
#define D6 pin_d6
#define D7 pin_d7
#define A0 pin_a0
#define A1 pin_a1
#define A2 pin_a2
#define A3 pin_a3
#define A4 pin_a4
#define A5 pin_a5



// Esta biblioteca foi modificada a partir da biblioteca original CCS, com o
// intuito de manter o padr�o de programa��o atendendo as necessidades do LCD
// para a esta��o did�tica CUSCOPIC. A defini��o dos pinos � :
// PINOS PIC  PINOS LCD
//        B0  enable
//        B1  rs
//        B2  rw
//        B4  D4
//        B5  D5
//        B6  D6
//        B7  D7
//
//   Os pinos D0 a D3 do LCD n�o s�o usados.

struct lcd_pin_map {                         // This structure is overlayed
                   BOOLEAN enable;           // on to an I/O port to gain
                   BOOLEAN rs;               // access to the LCD pins.
                   BOOLEAN rw;               // The bits are allocated from
                   BOOLEAN unused;           // low order up.  ENABLE will
                   int     data : 4;         // be pin B0.
                   } lcd;

#byte lcd = 6
#define set_tris_lcd(x) set_tris_b(x)
#define lcd_type 2           // 0=5x7, 1=5x10, 2=2 linhas
#define lcd_line_two 0x40    // Endereco de RAM da segunda linha


BYTE const LCD_INIT_STRING[4] = {0x20 | (lcd_type << 2), 0xc, 1, 6};
                             // Estes bytes sao enviados ao lcd para incicializa-lo

struct lcd_pin_map const LCD_WRITE = {0,0,0,0,0}; // For write mode all pins are out
struct lcd_pin_map const LCD_READ = {0,0,0,0,15}; // For read mode data pins are in

#separate
BYTE lcd_read_byte()
      {
      BYTE low,high;
      set_tris_lcd(LCD_READ);
      lcd.rw = 1;
      delay_cycles(1);
      lcd.enable = 1;
      delay_cycles(1);
      high = lcd.data;
      lcd.enable = 0;
      delay_cycles(1);
      lcd.enable = 1;
      delay_us(1);
      low = lcd.data;
      lcd.enable = 0;
      set_tris_lcd(LCD_WRITE);
      return( (high<<4) | low);
      }

#separate
void lcd_send_nibble( BYTE n )
      {
      lcd.data = n;
      delay_cycles(1);
      lcd.enable = 1;
      delay_us(2);
      lcd.enable = 0;
      }


// funcao abaixo modificada para evitar que o LCD trave o programa no caso de nao responder.

#separate
void lcd_send_byte( BYTE address, BYTE n )
      {
      int cont = 200;
      lcd.rs = 0;
      while ( bit_test(lcd_read_byte(),7) )
        {
        delay_us(50);
        cont --;
        if (!cont) break;
        }
      lcd.rs = address;
      delay_cycles(1);
      lcd.rw = 0;
      delay_cycles(1);
      lcd.enable = 0;
      lcd_send_nibble(n >> 4);
      lcd_send_nibble(n & 0xf);
      }

short lcd_initialized = 0;

#separate
void lcd_init()
    {
    BYTE i;
    set_tris_lcd(LCD_WRITE);
    lcd.rs = 0;
    lcd.rw = 0;
    lcd.enable = 0;
    delay_ms(15);
    for(i=1;i<=3;++i)
       {
       lcd_send_nibble(3);
       delay_ms(5);
       }
    lcd_send_nibble(2);
    for(i=0;i<=3;++i)
       lcd_send_byte(0,LCD_INIT_STRING[i]);
    lcd_initialized = 1;
    }


#separate
void lcd_gotoxy( BYTE x, BYTE y)
   {
   BYTE address;
   if(y!=1)
     address=lcd_line_two;
   else
     address=0;
   address+=x-1;
   lcd_send_byte(0,0x80|address);
   }

#separate
void lcd_putc( char c)
   {
   if (!lcd_initialized) lcd_init();
   else
   switch (c)
     {
     case '\f'   : lcd_send_byte(0,1);
                   delay_ms(2);
                                           break;
     case '\n'   : lcd_gotoxy(1,2);        break;
     case '\b'   : lcd_send_byte(0,0x10);  break;
     default     : lcd_send_byte(1,c);     break;
     }
   }

#separate
char lcd_getc( BYTE x, BYTE y)
    {
    char value;
    lcd_gotoxy(x,y);
    while ( bit_test(lcd_read_byte(),7) ); // wait until busy flag is low
    lcd.rs=1;
    value = lcd_read_byte();
    lcd.rs=0;
    return(value);
    }

// funcoes adicionadas por Daniel Corteletti

#separate
short lcd_connected()
    {
    int cont = 200;
    lcd.rs = 0;
    while ( bit_test(lcd_read_byte(),7) )
        {
        delay_us(50);
        cont --;
        if (!cont) return(0);
        }
    lcd.rs = 1;
    return(1);
    }

#separate
void lcd_cursor_on()
    {
    lcd_send_byte(0,0x0E);
    }

#separate
void lcd_cursor_blink()
    {
    lcd_send_byte(0,0x0F);
    }

#separate
void lcd_cursor_off()
    {
    lcd_send_byte(0,0x0C);
    }

#separate
void lcd_shift_left()
    {
    lcd_send_byte(0,0x18);
    }

#separate
void lcd_shift_right()
    {
    lcd_send_byte(0,0x1C);
    }




/*
*********************************************************************************
FUNCOES DE TECLADO
Baseada no layout da CUSCO IHM

B7----[ ]---[ ]---[ ]
       |     |     |
B5----[ ]---[ ]---[ ]
       |     |     |
B3----[ ]---[ ]---[ ]
       |     |     |
B2----[ ]---[ ]---[ ]
       |     |     |
       |     |     |
       B6    B4   B1

esta fun��o retorna o c�digo da tecla pressionada, conforme a seguinte tabela :

00h - TECLA 0 PRESSIONADA              01h - TECLA 1 PRESSIONADA              02h - TECLA 2 PRESSIONADA
03h - TECLA 3 PRESSIONADA              04h - TECLA 4 PRESSIONADA              05h - TECLA 5 PRESSIONADA
06h - TECLA 6 PRESSIONADA              07h - TECLA 7 PRESSIONADA              08h - TECLA 8 PRESSIONADA
09h - TECLA 9 PRESSIONADA              10h - TECLA * PRESSIONADA              11h - TECLA # PRESSIONADA
FFh - NENHUMA TECLA PRESSIONADA
*/
#define KBD_NADA      0xff
#define KBD_0         0x00
#define KBD_1         0x01
#define KBD_2         0x02
#define KBD_3         0x03
#define KBD_4         0x04
#define KBD_5         0x05
#define KBD_6         0x06
#define KBD_7         0x07
#define KBD_8         0x08
#define KBD_9         0x09
#define KBD_ASTERISCO 0x10
#define KBD_SUSTENIDO 0x11

#define TECLA_NADA    cusco_tecla_press(KBD_NADA)
#define TECLA_0       cusco_tecla_press(KBD_0)
#define TECLA_1       cusco_tecla_press(KBD_1)
#define TECLA_2       cusco_tecla_press(KBD_2)
#define TECLA_3       cusco_tecla_press(KBD_3)
#define TECLA_4       cusco_tecla_press(KBD_4)
#define TECLA_5       cusco_tecla_press(KBD_5)
#define TECLA_6       cusco_tecla_press(KBD_6)
#define TECLA_7       cusco_tecla_press(KBD_7)
#define TECLA_8       cusco_tecla_press(KBD_8)
#define TECLA_9       cusco_tecla_press(KBD_9)
#define TECLA_AST     cusco_tecla_press(KBD_ASTERISCO)
#define TECLA_SUS     cusco_tecla_press(KBD_SUSTENIDO)



short cusco_tecla_press(int ctecla)
  {
  short flag=0;
  output_b(0);
  delay_us(500);
  switch (ctecla)
     {
     case KBD_0         : output_high(PIN_B4);
                          output_low(PIN_B2);
                          input(PIN_B4);
                          delay_us(20);
                          if (!input(PIN_B4)) flag=1;
                          output_low(PIN_B4);
                          output_high(PIN_B2);
                          input(PIN_B4);
                          delay_us(20);
                          if (!input(PIN_B4)) flag=0;
                          break;

     case KBD_1         : output_high(PIN_B6);
                          output_low(PIN_B7);
                          input(PIN_B6);
                          delay_us(20);
                          if (!input(PIN_B6)) flag=1;
                          output_low(PIN_B6);
                          output_high(PIN_B7);
                          input(PIN_B6);
                          delay_us(20);
                          if (!input(PIN_B6)) flag=0;
                          break;

     case KBD_2         : output_high(PIN_B4);
                          output_low(PIN_B7);
                          input(PIN_B4);
                          delay_us(20);
                          if (!input(PIN_B4)) flag=1;
                          output_low(PIN_B4);
                          output_high(PIN_B7);
                          input(PIN_B4);
                          delay_us(20);
                          if (!input(PIN_B4)) flag=0;
                          break;

     case KBD_3         : output_high(PIN_B7);
                          output_low(PIN_B1);
                          input(PIN_B7);
                          delay_us(20);
                          if (!input(PIN_B7)) flag=1;
                          output_low(PIN_B7);
                          output_high(PIN_B1);
                          input(PIN_B7);
                          delay_us(20);
                          if (!input(PIN_B7)) flag=0;
                          break;

     case KBD_4         : output_high(PIN_B6);
                          output_low(PIN_B5);
                          input(PIN_B6);
                          delay_us(20);
                          if (!input(PIN_B6)) flag=1;
                          output_low(PIN_B6);
                          output_high(PIN_B5);
                          input(PIN_B6);
                          delay_us(20);
                          if (!input(PIN_B6)) flag=0;
                          break;

     case KBD_5         : output_high(PIN_B4);
                          output_low(PIN_B5);
                          input(PIN_B4);
                          delay_us(20);
                          if (!input(PIN_B4)) flag=1;
                          output_low(PIN_B4);
                          output_high(PIN_B5);
                          input(PIN_B4);
                          delay_us(20);
                          if (!input(PIN_B4)) flag=0;
                          break;

     case KBD_6         : output_high(PIN_B5);
                          output_low(PIN_B1);
                          input(PIN_B5);
                          delay_us(20);
                          if (!input(PIN_B5)) flag=1;
                          output_low(PIN_B5);
                          output_high(PIN_B1);
                          input(PIN_B5);
                          delay_us(20);
                          if (!input(PIN_B5)) flag=0;
                          break;

     case KBD_7         : output_high(PIN_B6);
                          output_low(PIN_B3);
                          input(PIN_B6);
                          delay_us(20);
                          if (!input(PIN_B6)) flag=1;
                          output_low(PIN_B6);
                          output_high(PIN_B3);
                          input(PIN_B6);
                          delay_us(20);
                          if (!input(PIN_B6)) flag=0;
                          break;

     case KBD_8         : output_high(PIN_B4);
                          output_low(PIN_B3);
                          input(PIN_B4);
                          delay_us(20);
                          if (!input(PIN_B4)) flag=1;
                          output_low(PIN_B4);
                          output_high(PIN_B3);
                          input(PIN_B4);
                          delay_us(20);
                          if (!input(PIN_B4)) flag=0;
                          break;

     case KBD_9         : output_high(PIN_B3);
                          output_low(PIN_B1);
                          input(PIN_B3);
                          delay_us(20);
                          if (!input(PIN_B3)) flag=1;
                          output_low(PIN_B3);
                          output_high(PIN_B1);
                          input(PIN_B3);
                          delay_us(20);
                          if (!input(PIN_B3)) flag=0;
                          break;

     case KBD_SUSTENIDO : output_high(PIN_B2);
                          output_low(PIN_B1);
                          input(PIN_B2);
                          delay_us(20);
                          if (!input(PIN_B2)) flag=1;
                          output_low(PIN_B2);
                          output_high(PIN_B1);
                          input(PIN_B2);
                          delay_us(20);
                          if (!input(PIN_B2)) flag=0;
                          break;

     case KBD_ASTERISCO : output_high(PIN_B6);
                          output_low(PIN_B2);
                          input(PIN_B6);
                          delay_us(20);
                          if (!input(PIN_B6)) flag=1;
                          output_low(PIN_B6);
                          output_high(PIN_B2);
                          input(PIN_B6);
                          delay_us(20);
                          if (!input(PIN_B6)) flag=0;
                          break;

     case KBD_NADA      : output_b(0b01010010);
                          input(PIN_B6);
                          input(PIN_B4);
                          input(PIN_B1);
                          delay_us(20);
                          if (input(PIN_B6) && input(PIN_B4) && input(PIN_B1)) flag=1;
                          break;



     }
  return(flag);
  }


int cusco_tecla()
  {
  output_b(0x7E); //01111110
  if (!input(PIN_B6)) return(KBD_1);
  if (!input(PIN_B4)) return(KBD_2);
  if (!input(PIN_B1)) return(KBD_3);
  output_b(0xDE); //11011110
  if (!input(PIN_B6)) return(KBD_4);
  if (!input(PIN_B4)) return(KBD_5);
  if (!input(PIN_B1)) return(KBD_6);
  output_b(0xF6); //11110110
  if (!input(PIN_B6)) return(KBD_7);
  if (!input(PIN_B4)) return(KBD_8);
  if (!input(PIN_B1)) return(KBD_9);
  output_b(0xFA); //11111010
  if (!input(PIN_B6)) return(KBD_ASTERISCO);
  if (!input(PIN_B4)) return(KBD_0);
  if (!input(PIN_B1)) return(KBD_SUSTENIDO);
  return(0xFF); // caso nada tenha sido pressionado
  }

// fim da fun��o de teclado LE_KB()
// ****************************************************************************************


/*
funcao cusco_readkbd()
retorna um valor do tipo INT32 (at� 9 digitos) lidos via teclado, escrevendo ou nao o valor
no display, na posicao onde estiver o cursor.

uso:

INT32 x;

x = cusco_readkbd(0);  <--- mostra o valor digitado.

ou

x = cusco_readkbd(1);  <--- mostra asteriscos no lugar do valor digitado

ou

x = cusco_readkbd(2); <--- nao mostra nada mas busca valor do teclado

o valor dever� ser inserido usando o teclado numerico matricial.
o valor finaliza com um enter (ou #)
a funcao retornar� o valor digitado ou -1 se for cancelado com um (*)
*/
short  cusco_readkbd_timeout = 0;
signed int32 cusco_readkbd(int echo)
 {
 int cont=0;
 int32 lido=0;
 int tecla;
 long timeout = 20000;
 while(true)
   {
   if (cusco_readkbd_timeout)
      {
      delay_ms(10);
      if (!timeout) return(-1);
      timeout --;
      }
   tecla = cusco_tecla();
   if (tecla == 0xff)       continue;
   timeout = 2000;
   if (tecla == 0x11)
      {
      do {
         delay_ms(10);
         } while(cusco_tecla() != 0xff);
      delay_ms(10);
      return(lido);
      }
   if (tecla == 0x10)
      {
      do {
         delay_ms(10);
         } while(cusco_tecla() != 0xff);
      delay_ms(10);
      return(-1);
      }
   delay_ms(10);
   if (cont < 9)
      {
      cont ++;
      lido = lido * 10;
      lido = lido + tecla;
      if(echo == 0) printf(lcd_putc,"%i",tecla);
      if(echo == 1) lcd_putc("*");
      output_high(pin_e2);
      delay_ms(10);
      output_low(pin_e2);
      delay_ms(90);
      }
   else
      {
      output_high(pin_e2);
      delay_ms(100);
      output_low(pin_e2);
      }
   while(tecla == cusco_tecla()) delay_ms(1);
   delay_ms(50);
   }
 }
// FIM DAS ROTINAS DE TECLADO PARA CUSCOPIC
//*******************************************************************************


long AD(int channel)
  {
  long aux;
  switch(channel)
    {
    case 0 : input(PIN_A0); break;
    case 1 : input(PIN_A1); break;
    case 2 : input(PIN_A2); break;
    case 3 : input(PIN_A3); break;
    case 4 : input(PIN_A5); break;
    default: return(0);
    }
  enable_interrupts( GLOBAL );
  setup_adc(  ADC_CLOCK_INTERNAL  );
  setup_adc_ports( ALL_ANALOG );
  set_adc_channel(channel);
  delay_us(100);
  aux = read_adc();
  setup_adc_ports(NO_ANALOGS);
  return(aux);
  }

void tempo_sound(int32 t)
  {
  while(t > 10000)
     {
     t-= 10000;
     delay_ms(100);
     }
  while(t > 1000)
     {
     t-= 1000;
     delay_ms(10);
     }
  while(t > 100)
     {
     t-= 100;
     delay_ms(1);
     }
  while(t > 10)
     {
     t-= 10;
     delay_us(90);
     }
  }

// gera audio, na frequencia e dura��o solicitada
#bit SPK = 0x09.2
void sound(long freq, long dur)
  {
  long P, PR;
  int32 duracao;
  duracao = (int32)dur * 10;
  PR = (long)50000/freq;
  P = PR;
  output_low(PIN_E2);
  while(duracao > 0)
    {
    duracao --;
    if (P > 5)
       P -= 5;
    else
       {
       SPK = ~SPK;
       P += PR;
       }
    delay_us(42);
    }
  SPK = 0;
  }

void beep()
  {
  int aux;
  for (aux = 0; aux < 100; aux ++)
    {
    output_high(BUZZER);
    delay_us(450);
    output_low(BUZZER);
    delay_us(450);
    }
  }

void disp7seg(long x)
  {
  int M,D,C,U;
  M = (x / 1000) % 10;
  C = (x % 1000) / 100;
  D = (x % 100) / 10;
  U = x % 10;
  output_b(M | 0x70); delay_us(10); output_high(PIN_B7);
  output_b(C | 0xB0); delay_us(10); output_high(PIN_B6);
  output_b(D | 0xD0); delay_us(10); output_high(PIN_B5);
  output_b(U | 0xE0); delay_us(10); output_high(PIN_B4);
  output_b(0xf0);     delay_ms(1);
  }

void disp7seg_clear()
  {
  output_b(0x0F); delay_us(100); output_b(0xff); delay_us(100);
  }

//==================================================


short FLAG_PULSO_D0 = 0,
      FLAG_PULSO_D1 = 0,
      FLAG_PULSO_D2 = 0,
      FLAG_PULSO_D3 = 0,
      FLAG_PULSO_D4 = 0,
      FLAG_PULSO_D5 = 0,
      FLAG_PULSO_D6 = 0,
      FLAG_PULSO_D7 = 0;

#separate
short PULSO(int PINO)
  {
  if (!input(PIN_D0)) FLAG_PULSO_D0 = 0;
  if (!input(PIN_D1)) FLAG_PULSO_D1 = 0;
  if (!input(PIN_D2)) FLAG_PULSO_D2 = 0;
  if (!input(PIN_D3)) FLAG_PULSO_D3 = 0;
  if (!input(PIN_D4)) FLAG_PULSO_D4 = 0;
  if (!input(PIN_D5)) FLAG_PULSO_D5 = 0;
  if (!input(PIN_D6)) FLAG_PULSO_D6 = 0;
  if (!input(PIN_D7)) FLAG_PULSO_D7 = 0;

  switch (PINO)
    {
    case pin_d0 : if (input(PIN_D0) && !FLAG_PULSO_D0)
                     {
                     FLAG_PULSO_D0 = 1;
                     return(1);
                     }
                  else
                     return(0);
    case pin_d1 : if (input(PIN_D1) && !FLAG_PULSO_D1)
                     {
                     FLAG_PULSO_D1 = 1;
                     return(1);
                     }
                  else
                     return(0);
    case pin_d2 : if (input(PIN_D2) && !FLAG_PULSO_D2)
                     {
                     FLAG_PULSO_D2 = 1;
                     return(1);
                     }
                  else
                     return(0);
    case pin_d3 : if (input(PIN_D3) && !FLAG_PULSO_D3)
                     {
                     FLAG_PULSO_D3 = 1;
                     return(1);
                     }
                  else
                     return(0);
    case pin_d4 : if (input(PIN_D4) && !FLAG_PULSO_D4)
                     {
                     FLAG_PULSO_D4 = 1;
                     return(1);
                     }
                  else
                     return(0);
    case pin_d5 : if (input(PIN_D5) && !FLAG_PULSO_D5)
                     {
                     FLAG_PULSO_D5 = 1;
                     return(1);
                     }
                  else
                     return(0);
    case pin_d6 : if (input(PIN_D6) && !FLAG_PULSO_D6)
                     {
                     FLAG_PULSO_D6 = 1;
                     return(1);
                     }
                  else
                     return(0);
    case pin_d7 : if (input(PIN_D7) && !FLAG_PULSO_D7)
                     {
                     FLAG_PULSO_D7 = 1;
                     return(1);
                     }
                  else
                     return(0);
    }
  return(0);
  }

int saidas_toogle_cusco = 0;

short toggle(int PINO)
  {
  output_d(0x00);
  delay_us(2);
  if (pulso(PIN_D0))
     {
     saidas_toogle_cusco ^= 0b00000001;
     }
  if (pulso(PIN_D1))
     {
     saidas_toogle_cusco ^= 0b00000010;
     }
  if (pulso(PIN_D2))
     {
     saidas_toogle_cusco ^= 0b00000100;
     }
  if (pulso(PIN_D3))
     {
     saidas_toogle_cusco ^= 0b00001000;
     }
  if (pulso(PIN_D4))
     {
     saidas_toogle_cusco ^= 0b00010000;
     }
  if (pulso(PIN_D5))
     {
     saidas_toogle_cusco ^= 0b00100000;
     }
  if (pulso(PIN_D6))
     {
     saidas_toogle_cusco ^= 0b01000000;
     }
  if (pulso(PIN_D7))
     {
     saidas_toogle_cusco ^= 0b10000000;
     }
  output_d(saidas_toogle_cusco);
  delay_ms(1);
  switch(PINO)
    {
    case PIN_D0 : return((saidas_toogle_cusco & 0b00000001) > 0);
    case PIN_D1 : return((saidas_toogle_cusco & 0b00000010) > 0);
    case PIN_D2 : return((saidas_toogle_cusco & 0b00000100) > 0);
    case PIN_D3 : return((saidas_toogle_cusco & 0b00001000) > 0);
    case PIN_D4 : return((saidas_toogle_cusco & 0b00010000) > 0);
    case PIN_D5 : return((saidas_toogle_cusco & 0b00100000) > 0);
    case PIN_D6 : return((saidas_toogle_cusco & 0b01000000) > 0);
    case PIN_D7 : return((saidas_toogle_cusco & 0b10000000) > 0);
    }
  return(0);
  }

//======================================= pwm =========================

#define PWM_250HZ_CLK4         setup_timer_2(T2_DIV_BY_16, 250, 1) //
#define PWM_500HZ_CLK4         setup_timer_2(T2_DIV_BY_16, 125, 1) //
#define PWM_1KHZ_CLK4          setup_timer_2(T2_DIV_BY_4, 250, 1)  //
#define PWM_1K25HZ_CLK4        setup_timer_2(T2_DIV_BY_16, 50, 1)  //
#define PWM_2KHZ_CLK4          setup_timer_2(T2_DIV_BY_4, 125, 1)  //
#define PWM_2K5HZ_CLK4         setup_timer_2(T2_DIV_BY_4, 100, 1)  //
#define PWM_4KHZ_CLK4          setup_timer_2(T2_DIV_BY_1, 250, 1)  //
#define PWM_5KHZ_CLK4          setup_timer_2(T2_DIV_BY_1, 200, 1)  //
#define PWM_8KHZ_CLK4          setup_timer_2(T2_DIV_BY_1, 125, 1)  //
#define PWM_10KHZ_CLK4         setup_timer_2(T2_DIV_BY_1, 100, 1)  //
#define PWM_20KHZ_CLK4         setup_timer_2(T2_DIV_BY_1,  50, 1)  //
#define PWM_25KHZ_CLK4         setup_timer_2(T2_DIV_BY_1,  40, 1)  //
#define PWM_100KHZ_CLK4        setup_timer_2(T2_DIV_BY_1, 10, 1)   //

#define PWM_500HZ_CLK8         setup_timer_2(T2_DIV_BY_16, 250, 1) //
#define PWM_1KHZ_CLK8          setup_timer_2(T2_DIV_BY_16, 125, 1) //
#define PWM_2KHZ_CLK8          setup_timer_2(T2_DIV_BY_4, 250, 1)  //
#define PWM_2K5HZ_CLK8         setup_timer_2(T2_DIV_BY_16, 50, 1)  //
#define PWM_4KHZ_CLK8          setup_timer_2(T2_DIV_BY_4, 125, 1)  //
#define PWM_5KHZ_CLK8          setup_timer_2(T2_DIV_BY_4, 100, 1)  //
#define PWM_8KHZ_CLK8          setup_timer_2(T2_DIV_BY_1, 250, 1)  //
#define PWM_10KHZ_CLK8         setup_timer_2(T2_DIV_BY_1, 200, 1)  //
#define PWM_16KHZ_CLK8         setup_timer_2(T2_DIV_BY_1, 125, 1)  //
#define PWM_20KHZ_CLK8         setup_timer_2(T2_DIV_BY_1, 100, 1)  //
#define PWM_40KHZ_CLK8         setup_timer_2(T2_DIV_BY_1,  50, 1)  //
#define PWM_50KHZ_CLK8         setup_timer_2(T2_DIV_BY_1,  40, 1)  //
#define PWM_200KHZ_CLK8        setup_timer_2(T2_DIV_BY_1, 10, 1)   //

#define PWM_1KHZ_CLK16         setup_timer_2(T2_DIV_BY_16, 250, 1) //
#define PWM_2KHZ_CLK16         setup_timer_2(T2_DIV_BY_16, 125, 1) //
#define PWM_4KHZ_CLK16         setup_timer_2(T2_DIV_BY_4, 250, 1)  //
#define PWM_5KHZ_CLK16         setup_timer_2(T2_DIV_BY_16, 50, 1)  //
#define PWM_8KHZ_CLK16         setup_timer_2(T2_DIV_BY_4, 125, 1)  //
#define PWM_10KHZ_CLK16        setup_timer_2(T2_DIV_BY_4, 100, 1)  //
#define PWM_16KHZ_CLK16        setup_timer_2(T2_DIV_BY_1, 250, 1)  //
#define PWM_20KHZ_CLK16        setup_timer_2(T2_DIV_BY_1, 200, 1)  //
#define PWM_32KHZ_CLK16        setup_timer_2(T2_DIV_BY_1, 125, 1)  //
#define PWM_40KHZ_CLK16        setup_timer_2(T2_DIV_BY_1, 100, 1)  //
#define PWM_80KHZ_CLK16        setup_timer_2(T2_DIV_BY_1,  50, 1)  //
#define PWM_100KHZ_CLK16       setup_timer_2(T2_DIV_BY_1,  40, 1)  //
#define PWM_400KHZ_CLK16       setup_timer_2(T2_DIV_BY_1, 10, 1)   //

#define PWM_800HZ_CLK10        setup_timer_2(T2_DIV_BY_16,195, 1) //
#define PWM_1KHZ_CLK10         setup_timer_2(T2_DIV_BY_16,156, 1) //
#define PWM_2KHZ_CLK10         setup_timer_2(T2_DIV_BY_16, 78, 1) //
#define PWM_4KHZ_CLK10         setup_timer_2(T2_DIV_BY_4, 156, 1)  //
#define PWM_5KHZ_CLK10         setup_timer_2(T2_DIV_BY_4, 125, 1)  //
#define PWM_8KHZ_CLK10         setup_timer_2(T2_DIV_BY_4,  78, 1)  //
#define PWM_10KHZ_CLK10        setup_timer_2(T2_DIV_BY_1, 250, 1)  //
#define PWM_16KHZ_CLK10        setup_timer_2(T2_DIV_BY_1, 156, 1)  //
#define PWM_20KHZ_CLK10        setup_timer_2(T2_DIV_BY_1, 125, 1)  //
#define PWM_32KHZ_CLK10        setup_timer_2(T2_DIV_BY_1,  78, 1)  //
#define PWM_40KHZ_CLK10        setup_timer_2(T2_DIV_BY_1,  62, 1)  //
#define PWM_80KHZ_CLK10        setup_timer_2(T2_DIV_BY_1,  31, 1)  //
#define PWM_100KHZ_CLK10       setup_timer_2(T2_DIV_BY_1,  25, 1)  //

//================================================================

long long_read_eeprom(int pos)   // l� da posi��o pos e pos+1 da eeprom (16 bits)
  {                              // devolvendo um long
  long aux;
  aux = read_eeprom(pos+1);
  aux = (aux << 8) + read_eeprom(pos);
  return(aux);
  }

int32 int32_read_eeprom(int pos)   // l� da posi��o pos,pos+1,pos+2,pos+3 da eeprom (32 bits)
  {                               // devolvendo um int32
  int32 aux;
  aux = read_eeprom(pos+3);
  aux = (aux << 8) + read_eeprom(pos+2);
  aux = (aux << 8) + read_eeprom(pos+1);
  aux = (aux << 8) + read_eeprom(pos);
  return(aux);
  }

//
void long_write_eeprom(int ender, long vlr)
  {
  int auxl, auxh;
  auxl = vlr % 256;
  auxh = vlr >> 8;
  write_eeprom(auxl, ender);
  write_eeprom(auxh, ender+1);
  }

void int32_write_eeprom(int ender, int32 vlr)
  {
  int aux, i;
  for(i=0; i<4; i ++)
    {
    aux=vlr%256;
    vlr = vlr >> 8;
    write_eeprom(ender+i, aux);
    }
  }

